package com.sujunjie;

import java.util.ArrayList;
import java.util.List;

import com.sujunjie.model.Card;
import com.sujunjie.model.Player;
import com.sujunjie.model.Sender;

public class Game extends Thread {

	private Sender sender = new Sender();

	private Player winnerPlayer = null;

	private Player player1;

	private Player player2;

	private Player player3;

	public Game() {
		sender = new Sender();
		player1 = new Player("player1");
		player2 = new Player("player2");
		player3 = new Player("player3");
	}

	public void startGame() throws InterruptedException {
		sender.initCards();
		int i = 1;
		while (true) {
			System.out.println("ROUND" + i);
			List<Card> sendCards = new ArrayList<Card>();
			try {
				sender.sendCard(player1, sendCards);
				sender.sendCard(player2, sendCards);
				sender.sendCard(player3, sendCards);

			} catch (Exception e) {
				System.out.println(e.getMessage());
				break;
			}

			Thread thread1 = new Thread(player1);
			Thread thread2 = new Thread(player2);
			Thread thread3 = new Thread(player3);
			thread1.start();
			thread2.start();
			thread3.start();
			while (thread1.isAlive() || thread2.isAlive() || thread3.isAlive()) {
				sleep(1000);
			}

			StringBuffer detail = new StringBuffer("Sender=[");
			for (Card card : sendCards) {
				detail.append(card.toString()).append(",");
			}
			detail.append("]->").append("player1=").append(player1.getScore())
					.append(",player2=").append(player2.getScore())
					.append(",player3=").append(player3.getScore());

			System.out.println(detail.toString());
			i++;

			if (checkScore()) {
				System.out.println(winnerPlayer.getName()+"win");
				break;
			}
		}
	}


	public boolean checkScore() {
		if (player1.getScore() > 50) {
			winnerPlayer = player1;
			return true;
		} else if (player2.getScore() > 50) {
			winnerPlayer = player2;
			return true;
		} else if (player3.getScore() > 50) {
			winnerPlayer = player3;
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void run() {
		try {
			startGame();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new Game().start();
	}

}
