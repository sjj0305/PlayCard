package com.sujunjie.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Sender {

	private List<Card> cards = new ArrayList<Card>();

	public void initCards() {
		cards.clear();
		for (Color color : Color.values()) {
			for (Point point : Point.values()) {
				cards.add(new Card(point, color));
			}
		}
		Collections.shuffle(cards);
	}
	
	public void sendCard(Player player,List<Card> sendCards) throws Exception{
		
		Iterator<Card> iterator = cards.iterator();
		if(iterator.hasNext()){
			Card card = iterator.next();
			sendCards.add(card);
			player.acceptCard(card);
			iterator.remove();
		}else{
			throw new Exception("Cards is Empty");
		}

	}

}
