package com.sujunjie.model;

public enum Point {

	ACE("A", 1), DEUCE("2", 2), THREE("3", 3), FOUR("4", 4), FIVE("5", 5), SIX(
			"6", 6), SERVEN("7", 7), EIGHT("8", 8), NINE("9", 9), TEN("10", 10), JACK(
			"J", 11), QUEEN("Q", 12), KING("K", 13);

	private String name;

	private int value;

	Point(String name, int value) {
		this.name = name;
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	
	
}