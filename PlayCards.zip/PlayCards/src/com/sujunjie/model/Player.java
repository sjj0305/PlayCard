package com.sujunjie.model;

import java.util.ArrayList;
import java.util.List;

public class Player implements Runnable {

	private List<Card> cards = new ArrayList<Card>();

	private int score = 0;

	private String name;

	public Player(String name) {
		this.name = name;
	}

	public void acceptCard(Card card) {
		cards.add(card);
	}

	public void calcuScore() {
		int score = 0;
		for (Card card : cards) {
			if ((Color.BLACK == card.getColor() || Color.RED == card.getColor())
					&& Point.JACK == card.getPoint()) {
				score = score + 20;
			} else {
				score = score + card.getPoint().getValue();
			}
		}

		this.score = score;
	}

	@Override
	public void run() {
		calcuScore();
	}

	public List<Card> getCards() {
		return cards;
	}

	public void setCards(List<Card> cards) {
		this.cards = cards;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
