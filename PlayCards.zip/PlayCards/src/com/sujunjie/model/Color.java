package com.sujunjie.model;

public enum Color {
	BLACK, RED, CLUBS, DIAMONDS;
}
